#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "header.h"
#include <string.h>

void write(char arqsai[30], int recursoes, int tamanho_vetor){
    FILE *saida;
    saida = fopen(arqsai,"a");
    fprintf(saida, "TAMANHO ENTRADA %d\n", tamanho_vetor);
    fprintf(saida, "SWAPS: %d\n", swaps);
    fprintf(saida, "RECURSOES: %d\n", recursoes);
    fprintf(saida, "TEMPO: %f\n", ms);

    swaps = 0;
    ms = 0;
    fclose(saida);
}

void troca(int *a, int *b){
    int aux;
    aux = *a;
    *a = *b;
    *b = aux;
    swaps = swaps+1;
}

int part_lomuto(int V[], int i, int f){
    int a, b;
    
    a = V[f];
    b = i-1;
    for(int j = i; j < f; j++){
        if(V[j] <= a){
            b++;
            troca(&V[b], &V[j]);
        }
    }
    b++;
    troca(&V[b], &V[f]);

    return b;
}

int part_hoare(int V[], int i, int f){
    int a, b;
    a = i-1;
    b = f+1;

    while(1){
        do{
            a = a+1;
        }while(V[a] < V[i]);

        do{
            b--;
        }while(V[b] > V[i]);

        if(a >= b)
            return b;
        troca(&V[a], &V[b]);
    }
}

int part_mediana(int V[], int i, int f, int p){
    int meio, aux1, aux2, aux3, indice = 0;
    meio = (i+f)/2;

    aux1 = V[i];
    aux2 = V[meio];
    aux3 = V[f];

    if(aux1 < aux2){
        if(aux2 < aux3){
            indice = meio;  // aux1 < aux2 < aux3 -> aux2 mediano
        }
        else{
            if(aux1 < aux3){
                indice = f;   // aux1 < aux3 && aux3 <= aux2 -> aux3 mediano
            }
            else{
                indice = i;  //aux3 <= aux1 && aux1 < aux2 -> aux1 mediano 
            }
        }
    }
    else{
        if(aux3 < aux2){
            indice = meio;  //aux3 < aux2 && aux2 <= aux1 -> aux2 mediano
        }
        else{
            if(aux3 < aux1){
                indice = f;  //aux2 <= aux3 && aux3 < aux1 -> aux3 mediano
            }
            else{
                indice = i;  //aux2 <= aux1 && aux1 <= aux3 -> aux1 mediano
            }
        }
    }

    aux1 = 0;
    switch(p){
        case 0:
            troca(&V[indice], &V[f]);
            aux1 = part_lomuto(V, i, f);
                break;
        case 1:
            troca(&V[indice], &V[i]);
            aux1 = part_hoare(V, i, f);
                break;
        default:
            break;

    }
    return aux1;
}

int part_random(int V[], int i, int f, int p){
    int r, k;

    r = 1 + i + (rand() % (f-i));

    switch(p){
        case 0:
            troca(&V[r], &V[f]);
            k = part_lomuto(V, i, f);
        case 1:
            troca(&V[r], &V[i]);
            k = part_hoare(V, i, f);
        default:
            break;
    }
    return k;
}

int quicksort(int V[], int i, int f, int e, int p){
    int k, r1=0, r2=0; //indice do vetor
    clock_t start, end;

    start = clock();

    if(i < f){
        if(e){
            if(p){
                k = part_random(V, i, f, p);
                r1 = quicksort(V, i, k, e, p);
                r2 = quicksort(V, k+1, f, e, p);
            }
            else{
                k = part_random(V, i, f, p);
                r1 = quicksort(V, i, k, e, p);
                r2 = quicksort(V, k+1, f, e, p);

            }
        } 
        else{
            if(p){
                k = part_mediana(V, i, f, p);
                r1 = quicksort(V, i, k, e, p);
                r2 = quicksort(V, k+1, f, e, p);
            }
            else{
                k = part_mediana(V, i, f, p);
                r1 = quicksort(V, i, k-1, e, p);
                r2 = quicksort(V, k+1, f, e, p);
            }
        }
    }
           
    end = clock();
    ms = (float)(end-start)/CLOCKS_PER_SEC;

    return (r1 + r2 + 1);
}
