#include <stdio.h>
#include <stdlib.h>


int select_h(int h, int tam, int op);
void shellsort(int V[], int tam, FILE *saida);
void shellsort2(int V[], int tam, FILE *saida);