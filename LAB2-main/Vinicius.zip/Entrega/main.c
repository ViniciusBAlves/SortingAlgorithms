#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"

int main(int argc, char *argv[]){
    FILE *entrada;
    int tamanho_vetor, recursoes, i;
	int *vetor =(int*) malloc(sizeof(int)*1000000);
    int *aux =(int*) malloc(sizeof(int)*1000000);
    char arqsai[30];

    entrada = fopen(argv[1],"r");    //Abre o primeiro arquivo de entrada passado como argumento para leitura
    if(entrada == NULL){
        printf("Arquivo de entrada invalido\n");
    }
    else{
        while (fscanf(entrada,"%d", &tamanho_vetor) != EOF) {  //le o primeiro elemento do vetor (tamanho), e se n�o for o final do arquivo, armazena numa variavel
            for (i=0; i<tamanho_vetor; i++)
                fscanf(entrada,"%d", &vetor[i]); //le o resto dos elementos da linha e armazena em um vetor

            for(i=0; i<tamanho_vetor; i++)
                aux[i] = vetor[i];
            recursoes = quicksort(aux, 0, tamanho_vetor-1, mediana, lomuto);
            for(int i = 0; i < tamanho_vetor; i++){
                printf("%d\t",aux[i]); //imprime os novos valores do vetor no arquivo de saida, junto com seu incremento
            }
            printf("\n");
            strcpy(arqsai,"stats-mediana-lomuto.txt");
            write(arqsai, recursoes, tamanho_vetor);


            for(i=0; i<tamanho_vetor; i++)
                aux[i] = vetor[i];
            recursoes = quicksort(aux, 0, tamanho_vetor-1, mediana, hoare);
            for(int i = 0; i < tamanho_vetor; i++){
                printf("%d\t",aux[i]); //imprime os novos valores do vetor no arquivo de saida, junto com seu incremento
            }
            printf("\n");
            strcpy(arqsai,"stats-mediana-hoare.txt");
            write(arqsai, recursoes, tamanho_vetor);

            for(i=0; i<tamanho_vetor; i++)
                aux[i] = vetor[i];
            recursoes = quicksort(aux, 0, tamanho_vetor-1, aleatorio, lomuto);
            for(int i = 0; i < tamanho_vetor; i++){
                printf("%d\t",aux[i]); //imprime os novos valores do vetor no arquivo de saida, junto com seu incremento
            }
            printf("\n");
            strcpy(arqsai,"stats-aleatorio-lomuto.txt");
            write(arqsai, recursoes, tamanho_vetor);

            for(i=0; i<tamanho_vetor; i++)
                aux[i] = vetor[i];
            recursoes = quicksort(aux, 0, tamanho_vetor-1, aleatorio, hoare);
            for(int i = 0; i < tamanho_vetor; i++){
                printf("%d\t",aux[i]); //imprime os novos valores do vetor no arquivo de saida, junto com seu incremento
            }
            printf("\n");
            strcpy(arqsai,"stats-aleatorio-hoare.txt");
            write(arqsai, recursoes, tamanho_vetor);
        }
    }

    fclose(entrada);

    //strcpy(arqsai,"stats-mediana-lomuto.txt");
    //saida = fopen(arqsai,"w");
    //fclose(saida);
    //strcpy(arqsai,"stats-mediana-hoare.txt");
    //saida = fopen(arqsai,"w");
    //fclose(saida);
    //strcpy(arqsai,"stats-aleatorio-lomuto.txt");
    //saida = fopen(arqsai,"w");
    //fclose(saida);
    //strcpy(arqsai,"stats-aleatorio-hoare.txt");
    //saida = fopen(arqsai,"w");
    //fclose(saida);

    return 0;
}


