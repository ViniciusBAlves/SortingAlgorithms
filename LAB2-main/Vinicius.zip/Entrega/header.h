#include <stdio.h>
#include <stdlib.h>

int swaps;
float ms;
int part_mediana(int V[], int i, int f, int p);
int part_lomuto(int V[], int i, int f);
int part_hoare(int V[], int i, int f);
int quicksort(int V[], int i, int f, int e, int p);
void troca(int *a, int *b);
enum escolha {mediana, aleatorio};
enum particionamento {lomuto, hoare};