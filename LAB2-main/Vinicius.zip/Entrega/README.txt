Arquivos Entregues:
header.h: Contém o cabeçalho das funções utilizadas no projeto.
funcoes.c: Contém as funções necessárias para implementação do Shell Sort.
main.c: Contém a parte principal do programa, a qual lê o arquivo com os vetores de números e efetua a chamada do Shell Sort para ordenar.
desafio.cpp: Contém o código da resolução do desafio DNA Sorting
entrada1.txt: Arquivo fornecido pelo Professor para uso no laboratório.
entrada2.txt: Arquivo fornecido pelo Professor para uso no laboratório.
saida1.txt: Arquivo de saída referente aos passos do Shell Sort na ordenação dos vetores do arquivo entrada1.txt
saida2.txt: Arquivo de saída referente aos tempos das diferentes sequências do Shell Sort na ordenação dos vetores do arquivo entrada2.txt
aceitacao_desafio.png: Print correspondente à aceitação do código do desafio no site https://vjudge.net/problem/UVA-612.


Integrantes:
Carlos Eduardo Menin
Vinicius Boff Alves

Aceitação do desafio no site vdjuge.net/problem/UVA-612:
#37088283 | CarlosMenin's solution for [UVA-612]
Status:
Accepted
Time:
60ms
Length:
1267
Lang:
C++ 5.3.0
Submitted:
2022-07-10 19:37:25
RemoteRunId:
27639320